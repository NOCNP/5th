/*
Q-Group(57-120)
Lab Class- 9
17-10-23
Write a C program to implement memeory management with fixed partitioning technique. 
MFT

Full Form-

nob = Number of Blocks
bs = Block Size
ms = Memory Available
ef = External Fragmentation
tif = Total Internal Fragmentation
mp = Memeory Required For Process

*/


#include<stdio.h>
int main()
{
    int ms, bs, nob, ef, n, mp[10], tif = 0, i, p = 0;

    printf("Enter The Total Memory Available (In Bytes) -- ");
    scanf("%d", &ms);

    printf("Enter The Block Size (In Bytes) -- ");
    scanf("%d", &bs);

    nob = ms / bs;
    ef = ms - nob * bs;

    printf("\nEnter The Number of Processes -- ");
    scanf("%d", &n);
    printf("\n");

    for(i = 0; i < n; i++)
    {
        printf("Enter Memory Required for Process %d (In Bytes)-- ", i + 1);
        scanf("%d", &mp[i]);
    }

    printf("\nNo. of Blocks Available in Memory-- %d", nob);
    printf("\n\nProcess\t Memory Required\t Allocated\t Internal Fragmention\n");

    for(i = 0; i < n && p < nob; i++)
    {
        printf("\n %d\t\t %d", i + 1, mp[i]);

        if(mp[i] > bs)
            printf("\t\t NO\t\t ---");

        else
        {
            printf("\t\t YES\t\t %d", bs - mp[i]);
            tif = tif + bs - mp[i];
            p++;
        }
    }

    if(i < n)
        printf("\n\nMemory is Full, Remaining Processes cannot be Accommodate.");

    printf("\n\nTotal Internal Fragmentation is: %d\n", tif);
    printf("Total External Fragmentation is: %d\n", ef);

    return 0;
}



/*

1000
300
5
275
400
290
293
100


Sample Input/Output:

Enter The Total Memory Available (In Bytes) -- 1000
Enter The Block Size (In Bytes) -- 300

Enter The Number of Processes -- 5

Enter Memory Required for Process 1 (In Bytes)-- 275
Enter Memory Required for Process 2 (In Bytes)-- 400
Enter Memory Required for Process 3 (In Bytes)-- 290
Enter Memory Required for Process 4 (In Bytes)-- 293
Enter Memory Required for Process 5 (In Bytes)-- 100

No. of Blocks Available in Memory-- 3

Process  Memory Required         Allocated       Internal Fragmention


 1               275             YES             25
 2               400             NO              ---
 3               290             YES             10
 4               293             YES             7

Memory is Full, Remaining Processes cannot be Accommodate.

Total Internal Fragmentation is: 42
Total External Fragmentation is: 100

*/