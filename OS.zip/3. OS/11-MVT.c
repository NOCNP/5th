// MVT
/*
Q-Group(57-120)
Lab Class- 10
30-10-23
Write a C program to implement memeory management with variable partitioning technique. 
(MVT)

*/

#include<stdio.h>
int main()
{
    int ms, mp[10], i, temp, n = 0;
    char ch = 'y';

    printf("Enter The Total Memory Availble (in Bytes)-- ");
    scanf("%d", &ms);

    temp = ms;

    for(i = 0; ch == 'y'; i++, n++)
    {
        printf("\nEnter Memory Required For Process %d (in Bytes)-- ", i + 1);
        scanf("%d", &mp[i]);

        if(mp[i] <= temp)
        {
            printf("\nMemory is Allocated For Process %d", i + 1);
            temp = temp - mp[i];
        }

        else
        {
            printf("\nMemory is Full");
            break;
        }

        printf("\nDo you want to continue (y/n) -- ");
        scanf(" %c", &ch);

    }

    printf("\n\nTotal Memoery Available -- %d", ms);
    printf("\n\n\tPROCESS\t\tMEMORY ALLOCATED");

    for(i = 0; i < n; i++)
        printf("\n\t%d\t\t%d", i + 1, mp[i]);

    printf("\n\nTotal Memory Allocated is: %d\n", ms - temp);
    printf("Total External Fragmentation is: %d\n", temp);

    return 0;
}


/*

Sample Input/Output:

Enter The Total Memory Availble (in Bytes)-- 1000

Enter Memory Required For Process 1 (in Bytes)-- 400      

Memory is Allocated For Process 1
Do you want to continue (y/n) -- y

Enter Memory Required For Process 2 (in Bytes)-- 275

Memory is Allocated For Process 2
Do you want to continue (y/n) -- y

Enter Memory Required For Process 3 (in Bytes)-- 550

Memory is Full

Total Memoery Available -- 1000

        PROCESS         MEMORY ALLOCATED
        1               400
        2               275

Total Memory Allocated is: 675
Total External Fragmentation is: 325

*/
